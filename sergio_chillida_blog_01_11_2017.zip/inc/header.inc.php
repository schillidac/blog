<header id="cabecera">
	<h1>
		<a href="/index.php">
			<img src="/imagenes/logo.png" alt="mi blog">
		</a>
	</h1>
	<nav id="menu-principal">
		<ul>
			<li>
				<a href="/index.php">Inicio</a>
			</li>
			<li>
				<a href="/login.php">Login</a>
			</li>
			<li>
				<a href="/registro.php">Registro</a>
			</li>
		</ul>
	</nav>
</header>